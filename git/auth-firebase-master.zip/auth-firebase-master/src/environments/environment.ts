export const environment = {
  firebase: {
    projectId: 'angular-auth-c7966',
    appId: '1:78539156689:web:b1ca5b34f72ff800cb29f0',
    storageBucket: 'angular-auth-c7966.appspot.com',
    apiKey: 'AIzaSyBpg3k4szYlan6QkriKhrlDEVzFysC6tyc',
    authDomain: 'angular-auth-c7966.firebaseapp.com',
    messagingSenderId: '78539156689',
  },
};